let handler = async m => m.reply(`
                
  ━━━〔 *AIINE×* 〕━━ꕥ
━━━〔 ıll *HARGA llı BOT* 〕━━ꕥ
⬡ *DANA:* *Rp. 10.000 • 30 HARI*
⬡ *PULSA:* *Rp. 15.000 • 30 HARI*
⬡ *BISA TRIAL SELAMA 10JAM*
┗━━━━━━━━━━━━━━━ꕥ
╭━━━━「 *PREMIUM* 」
┊⫹⫺ *Hemat:* _10k (1 bulan)_
┊⫹⫺ *Normal:* _20k (2 Bulan)_
┊
╰═┅═━––––––๑
*⫹⫺ PAYMENT:*
• *Pulsa:* [081283186765]
• *Dana:* [081283186765]
–––––– *🐾 Kebijakan* ––––––
🗣️: Kak, Kok harganya mahal banget?
💬: Mau tawar menawar? boleh, silahkan chat owner aja

🗣️: Scam ga nih kak?
💬: Enggalah, Owner 100% Tepati janji #STAYHALAL
*[ Fitur ]*
*> Add List Jualan Kamu*
*> Anti Link*
*> Welcome*
*> Group*
*> Anime*
*> Stalking*
*> Search*
*> Convert*
*> Image Efek*
*> Anime Random*
*> Nsfw*
*> Game*
*> Viral*
Dan lain lain :v
*JIKA ANDA BERMINAT HUBUNGI NOMOR DI BAWAH !!*
*http://Wa.me/6281283186765?text=‘assalamualaikum%20bang%20saya%20mau%20sewabotnya%20Boleh%20ngak*
*Link Group Bot*
*https://chat.whatsapp.com/FJsZYhgE5aX3IMo8BOLvRo*
`.trim())// Tambah sendiri kalo mau
handler.help = ['sewa']
handler.tags = ['main']
handler.command = /^(sewa)$/i

module.exports = handler