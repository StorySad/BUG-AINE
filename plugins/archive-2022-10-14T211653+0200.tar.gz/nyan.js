let fetch = require("node-fetch")
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn}) => {
  try {
  let res = await fetch('https://neko-love.xyz/api/v1/neko')
  let json = await res.json()
  let { 
url
} = json
let stiker = await sticker(null, url, 'Neko', global.author)
  conn.sendFile(m.chat, stiker, 'stiker.webp', '', '', {
    quoted: m
  })
 } catch (e) {
  }
}
handler.command = /^nyan/i
handler.register = true

module.exports = handler